def f(value1):
    def multiply(value2):
        return value1 * value2
    return multiply
