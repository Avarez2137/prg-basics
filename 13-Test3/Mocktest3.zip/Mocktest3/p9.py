def f(uid):
    return len(uid) == len(set(uid))
